package com.cts.grizzlystoreadminwebapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.grizzlystoreadminwebapp.bean.Login;
import com.cts.grizzlystoreadminwebapp.dao.LoginDAO;
@Service("LoginService")
@Transactional(propagation=Propagation.SUPPORTS)
public class LoginServiceImpl implements LoginService {
	
	@Autowired
	private LoginDAO loginDAO;

	@Override
	public int getUserStatus(String id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getUserType(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Login authenticate(String userName, String password) {
		// TODO Auto-generated method stub
		return loginDAO.authenticate(userName, password);
	}

}
