package com.cts.grizzlystoreadminwebapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.grizzlystoreadminwebapp.bean.Vendors;
import com.cts.grizzlystoreadminwebapp.dao.VendorsDAO;
@Service("vendorsService")
@Transactional(propagation=Propagation.SUPPORTS)
public class VendorsServiceImpl implements VendorsService {
	
	@Autowired
	private VendorsDAO vendorsDAO;

	@Override
	public String getVendors() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String insertVendros(Vendors vendors) {
		// TODO Auto-generated method stub
		return null;
	}

}
