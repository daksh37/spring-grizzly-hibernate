package com.cts.grizzlystoreadminwebapp.dao;

import com.cts.grizzlystoreadminwebapp.bean.Vendors;

public interface VendorsDAO {
	
	public String getVendors();
	public String insertVendros(Vendors vendors);

}
