package com.cts.grizzlystoreadminwebapp.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.grizzlystoreadminwebapp.bean.Login;
@Repository("LoginDAO")
public class LoginDAOImpl implements LoginDAO {
	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	
	@Override
	public int getUserStatus(String id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getUserType(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Transactional
	public Login authenticate(String userName, String password) {
		// TODO Auto-generated method stub
		Session session=null;
		String query ="from Login where userName=? AND password=?";
		org.hibernate.query.Query<Login> query2=null;
		try{
			session=sessionFactory.getCurrentSession();
			query2=session.createQuery(query);
			query2.setParameter(0,userName);
			query2.setParameter(1,password);
			Login login=new Login();
			login=query2.getSingleResult();
			System.out.println(login.getUserName());
			return login;
		}
		catch(Exception e){
			e.printStackTrace();
			}
		return null;

	}
	
}
