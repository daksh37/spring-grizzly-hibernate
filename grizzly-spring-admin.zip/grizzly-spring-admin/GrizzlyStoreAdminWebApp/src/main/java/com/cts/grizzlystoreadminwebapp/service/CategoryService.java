package com.cts.grizzlystoreadminwebapp.service;

import java.util.List;

import com.cts.grizzlystoreadminwebapp.bean.Category;

public interface CategoryService {
	
	public String getCategoryName();
	public List<Category> getCategory();
	public String insertCategory(Category category);

}
