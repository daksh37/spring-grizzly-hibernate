package com.cts.grizzlystoreadminwebapp.dao;

import java.util.List;

import com.cts.grizzlystoreadminwebapp.bean.Product;

public interface ProductDAO {
	
	public List<Product> getProduct();
	public String insertProduct(Product product);

}
