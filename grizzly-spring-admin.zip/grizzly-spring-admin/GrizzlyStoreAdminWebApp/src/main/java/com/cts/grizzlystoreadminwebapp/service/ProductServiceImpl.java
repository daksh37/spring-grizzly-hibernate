package com.cts.grizzlystoreadminwebapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.grizzlystoreadminwebapp.bean.Product;
import com.cts.grizzlystoreadminwebapp.dao.ProductDAO;

@Service("productService")
@Transactional(propagation=Propagation.SUPPORTS)
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductDAO productDAO;

	@Override
	public List<Product> getProduct() {
		// TODO Auto-generated method stub
		return productDAO.getProduct();
	}

	@Override
	public String insertProduct(Product product) {
		// TODO Auto-generated method stub
		return productDAO.insertProduct(product);
	}

}
