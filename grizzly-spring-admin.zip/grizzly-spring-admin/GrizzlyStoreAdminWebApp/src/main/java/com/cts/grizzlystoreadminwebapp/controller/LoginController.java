package com.cts.grizzlystoreadminwebapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.grizzlystoreadminwebapp.bean.Login;
import com.cts.grizzlystoreadminwebapp.bean.Product;
import com.cts.grizzlystoreadminwebapp.service.LoginService;
import com.cts.grizzlystoreadminwebapp.service.ProductService;

@Controller
public class LoginController {
@Autowired
LoginService loginService;


@Autowired
ProductService productService;

@RequestMapping(value="login.html",method=RequestMethod.POST)
public ModelAndView validateUser(@ModelAttribute Login login){
	ModelAndView modelAndView =new ModelAndView();
	if (loginService.authenticate(login.getUserName(), login.getPassword())!=null){
		Login login2=loginService.authenticate(login.getUserName(), login.getPassword());
		modelAndView.addObject("user", login2);
		List<Product> products=productService.getProduct();
		
		modelAndView.addObject("products", products);
		System.out.println(products);
		modelAndView.setViewName("adminHome");
	}else{
		modelAndView.setViewName("login");
	}
	
	return modelAndView;
}

}




