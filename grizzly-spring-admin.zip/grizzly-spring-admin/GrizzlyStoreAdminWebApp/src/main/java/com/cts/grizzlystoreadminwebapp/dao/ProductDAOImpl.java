package com.cts.grizzlystoreadminwebapp.dao;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.grizzlystoreadminwebapp.bean.Login;
import com.cts.grizzlystoreadminwebapp.bean.Product;
@Repository("productDAO")
public class ProductDAOImpl implements ProductDAO {
	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	
	@Transactional
	public List<Product> getProduct() {
		// TODO Auto-generated method stub
		Session session=null;
		try{
			String query="from Product";
			Query<Product> query2=null;
			session =sessionFactory.getCurrentSession();
			query2=session.createQuery(query);
			List<Product> products =query2.getResultList();
			if(products==null){
				return null;
			}
			return products;
			}
			catch(Exception e){
				e.printStackTrace();
			}
		return null;

		
	}

	@Transactional
	public String insertProduct(Product product) {
		// TODO Auto-generated method stub
		Session session=null;
		try{
			session=sessionFactory.getCurrentSession();
			session.save(product);
			return "true";
		}
		catch(Exception e){
			e.printStackTrace();
			}
		return null;

	}
	}


