package com.cts.grizzlystoreadminwebapp.dao;

import org.springframework.stereotype.Repository;

import com.cts.grizzlystoreadminwebapp.bean.Vendors;
@Repository("vendorsDAO")
public class VendorsDAOImpl implements VendorsDAO {

	@Override
	public String getVendors() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String insertVendros(Vendors vendors) {
		// TODO Auto-generated method stub
		return null;
	}

}
