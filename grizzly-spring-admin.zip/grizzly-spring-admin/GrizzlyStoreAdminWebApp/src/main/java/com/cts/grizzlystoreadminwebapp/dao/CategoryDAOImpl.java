package com.cts.grizzlystoreadminwebapp.dao;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.grizzlystoreadminwebapp.bean.Category;

@Repository("categoryDAO")
public class CategoryDAOImpl implements CategoryDAO {
	
	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;

	@Override
	public String getCategoryName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Transactional(readOnly=true)
	public List<Category> getCategory() {
		Session session = null;
		String query= "from Category ";
	org.hibernate.query.Query<Category> query2=null;
	
		//try {
			session = sessionFactory.getCurrentSession();
			query2=session.createQuery(query);
			List<Category> list = query2.getResultList();
			System.out.println("Hello");
			return list;
	/*	} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;*/
		
	}

	@Transactional
	public String insertCategory(Category category) {
		// TODO Auto-generated method stub
				Session session = null;
				try {
					session = sessionFactory.getCurrentSession();
					session.save(category);
				} catch (Exception e) {
					e.printStackTrace();
				}
				if(category==null){
					return "fail";
				}
				else{
					return "category added";
				}
	}

	

}