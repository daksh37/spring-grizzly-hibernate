package com.cts.grizzlystoreadminwebapp.service;

import com.cts.grizzlystoreadminwebapp.bean.Vendors;

public interface VendorsService {
	
	public String getVendors();
	public String insertVendros(Vendors vendors);

}
