package com.cts.grizzlystoreadminwebapp.service;

import java.util.List;

import com.cts.grizzlystoreadminwebapp.bean.Product;

public interface ProductService {
	
	public List<Product> getProduct();
	public String insertProduct(Product product);

}
