package com.cts.grizzlystoreadminwebapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cts.grizzlystoreadminwebapp.bean.Category;
import com.cts.grizzlystoreadminwebapp.bean.Product;
import com.cts.grizzlystoreadminwebapp.service.CategoryService;

@Controller
public class CategoryController {
	
	
	@Autowired
	private CategoryService categoryService;
	
	
	
	@RequestMapping("addCategory.html")
	public String getAddCategory(){
		return "addCategory";
	}

	@PostMapping("addCategory.html")
	public ModelAndView saveCategory(@ModelAttribute Category category ){
		ModelAndView modelAndView = new ModelAndView();
		if(categoryService.insertCategory(category)!=null){
			
			modelAndView.setViewName("done");
		}
		else{
			modelAndView.setViewName("fails");
		}
		return modelAndView;
	   }

}