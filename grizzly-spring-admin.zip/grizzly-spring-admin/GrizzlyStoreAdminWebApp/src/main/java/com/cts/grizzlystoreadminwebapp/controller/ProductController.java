package com.cts.grizzlystoreadminwebapp.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.grizzlystoreadminwebapp.bean.Login;
import com.cts.grizzlystoreadminwebapp.bean.Product;
import com.cts.grizzlystoreadminwebapp.service.CategoryService;
import com.cts.grizzlystoreadminwebapp.service.LoginService;
import com.cts.grizzlystoreadminwebapp.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	ProductService productService;
	
	@Autowired
	private CategoryService categoryService;
	
	@RequestMapping("addProduct.html")
	public String getAddProduct(){
	return "addProduct";
	}

	@RequestMapping("addProduct12.html")
	public ModelAndView categoryfetch(@ModelAttribute Product product ){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("category",categoryService.getCategory());
		modelAndView.setViewName("addProduct");
		return modelAndView;
}
	@RequestMapping(value="addProduct.html",method=RequestMethod.POST)
	public ModelAndView addProduct(@ModelAttribute  Product product ,HttpSession session){
	
		ModelAndView modelAndView =new ModelAndView();
		if ("true".equals(productService.insertProduct(product))){
			System.out.println("succe");
		}else{
		System.out.println("fail");
	}
	
	return modelAndView;
}

}
