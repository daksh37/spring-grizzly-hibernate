package com.cts.grizzlystoreadminwebapp.dao;

import java.util.List;

import com.cts.grizzlystoreadminwebapp.bean.Category;

public interface CategoryDAO {
	
	public String getCategoryName();
	public List<Category> getCategory();
	public String insertCategory(Category category);

}
