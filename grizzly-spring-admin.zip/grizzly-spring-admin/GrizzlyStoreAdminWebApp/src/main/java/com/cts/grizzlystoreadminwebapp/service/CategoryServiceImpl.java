package com.cts.grizzlystoreadminwebapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.grizzlystoreadminwebapp.bean.Category;
import com.cts.grizzlystoreadminwebapp.dao.CategoryDAO;
@Service("categoryService")
@Transactional(propagation=Propagation.SUPPORTS)
public class CategoryServiceImpl implements CategoryService {
	
	@Autowired
	private CategoryDAO categoryDAO;

	@Override
	public String getCategoryName() {
		// TODO Auto-generated method stub
		return categoryDAO.getCategoryName();
	}

	@Override
	public List<Category> getCategory() {
		// TODO Auto-generated method stub
		return categoryDAO.getCategory();
	}

	@Override
	public String insertCategory(Category category) {
		// TODO Auto-generated method stub
		return categoryDAO.insertCategory(category);
	}

}
